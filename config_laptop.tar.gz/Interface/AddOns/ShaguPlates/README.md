# ShaguPlates
A Vanilla Addon that modifies and extends the default nameplates

**Notice:**
*This Addon or a superior and maintained version of it, is already included in [pfUI](https://github.com/shagu.pfUI). If using this in combination with pfUI you might get bad results or up to performance regressions.*

# Screenshot
![1](http://shagu.org/shagucollection/img/ShaguPlates.jpg)
