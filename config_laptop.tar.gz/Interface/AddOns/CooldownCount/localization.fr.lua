
if ( GetLocale ) and ( GetLocale() == "frFR" ) then

	COOLDOWNCOUNT_CLASS_ROGUE							= "Voleur";

end
