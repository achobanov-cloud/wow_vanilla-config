if (GetLocale() == "koKR") then

AtlasLootWBBossButtons = {
    Kazzak = {
       "KKazzak";
       };

    FourDragons = {
       "DLethon";
       "DEmeriss";
       "DTaerar";
       "DYsondre";
       };
    Azuregos = {
       "AAzuregos";
       };
    };

end

