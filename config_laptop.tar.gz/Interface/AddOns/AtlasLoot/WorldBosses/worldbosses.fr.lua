if (GetLocale() == "frFR") then

AtlasLootWBBossButtons = {
    Kazzak = {
       "KKazzak";
       };

    FourDragons = {
       "DLethon";
       "DEmeriss";
       "DTaerar";
       "DYsondre";
       };
    Azuregos = {
       "AAzuregos";
       };
    };
    

end

