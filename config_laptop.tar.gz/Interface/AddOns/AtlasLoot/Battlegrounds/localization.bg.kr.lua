if (GetLocale() == "koKR") then

------------
-- Layout --
------------
AtlasLootBattlegrounds = {

    AlteracValleyNorth = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "AVFriendly";
        "AVHonored";
        "AVRevered";
        "AVExalted";
	"PVPSET";
    };
    
    AlteracValleySouth = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "AVFriendly";
        "AVHonored";
        "AVRevered";
        "AVExalted";
	"PVPSET";
    };
    
    ArathiBasin = {
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "";
        "ABFriendly";
        "ABHonored";
        "ABRevered";
        "ABExalted";
	"PVPSET";
    };
    
    WarsongGulch = {
        "";
        "";
        "";
        "WSGFriendly";
        "WSGHonored";
        "WSGRevered";
        "WSGExalted";
	"PVPSET";
    };
};
end
