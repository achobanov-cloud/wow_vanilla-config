
# SP_Overpower
	Author: EinBaum (known as Bulldozer @ Emerald Dream)

### About

	Shows an alert tooltip and timer bar on your screen when Overpower proccs.
	Works in all stances and plays a sound.

### Settings

	General help and info:
		/op

	Get bar X-position:
		/op x

	Get bar Y-position:
		/op y

	Change x-position:
		/op x [number]

	Change y-position:
		/op y [number]

	Change height:
		/op h [number]

	Change width:
		/op w [number]

	Change alpha:
		/op a [number] *(between 0-1)*

	Get scale:
		/st s

	Change scale:
		/st s [number]

	Turn sound on or off:
		/op sound [on|off]

	Reset all settings to default values:
		/op reset

	Show the timer. For testing only.
		/op show
