
CharactersViewerProfile = {
	["RetroWoW"] = {
		["Mevolent"] = {
			["Equipment"] = {
				[1] = {
					["T"] = "Interface\\Icons\\INV_Helmet_52",
					["L"] = "item:19375:2588:0:0",
				},
				[2] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_10",
					["L"] = "item:22403:0:0:0",
				},
				[3] = {
					["T"] = "Interface\\Icons\\INV_Shoulder_25",
					["L"] = "item:22499:0:0:0",
				},
				[4] = {
					["T"] = "Interface\\Icons\\INV_Shirt_01",
					["L"] = "item:6096:0:0:0",
				},
				[5] = {
					["T"] = "Interface\\Icons\\INV_Chest_Cloth_48",
					["L"] = "item:21838:0:0:0",
				},
				[6] = {
					["T"] = "Interface\\Icons\\INV_Belt_12",
					["L"] = "item:22730:0:0:0",
				},
				[7] = {
					["T"] = "Interface\\Icons\\INV_Pants_Cloth_08",
					["L"] = "item:21346:0:0:0",
				},
				[8] = {
					["T"] = "Interface\\Icons\\INV_Boots_Cloth_03",
					["L"] = "item:21344:0:0:0",
				},
				[9] = {
					["T"] = "Interface\\Icons\\INV_Bracer_07",
					["L"] = "item:19374:0:0:0",
				},
				[10] = {
					["T"] = "Interface\\Icons\\INV_Gauntlets_14",
					["L"] = "item:16913:0:0:0",
				},
				[11] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_AhnQiraj_02",
					["L"] = "item:21709:0:0:0",
				},
				[12] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_51Naxxramas",
					["L"] = "item:23062:0:0:0",
				},
				[13] = {
					["T"] = "Interface\\Icons\\INV_Misc_Root_02",
					["L"] = "item:12930:0:0:0",
				},
				[14] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Talisman_08",
					["L"] = "item:13968:0:0:0",
				},
				[15] = {
					["T"] = "Interface\\Icons\\INV_Misc_Cape_18",
					["L"] = "item:22731:0:0:0",
				},
				[16] = {
					["T"] = "Interface\\Icons\\INV_Staff_20",
					["L"] = "item:21273:0:0:0",
				},
				[18] = {
					["T"] = "Interface\\Icons\\INV_Wand_1H_Stratholme_D_02",
					["L"] = "item:22821:0:0:0",
				},
			},
			["Type"] = "Self",
			["Bag"] = {
				[1] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					["name"] = "Bottomless Bag",
					[17] = {
					},
					[18] = {
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[2] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_ClothBelt",
						["L"] = "item:22370:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Idol_02",
						["L"] = "item:19818:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:23055:0:0:0",
					},
					[4] = {
						["C"] = 12,
						["L"] = "item:22682:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Rune_09",
					},
					[5] = {
						["C"] = 28,
						["L"] = "item:22376:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_WartornScrap_Cloth",
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_ClothGlove",
						["L"] = "item:22371:0:0:0",
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Potion_73",
						["L"] = "item:6149:0:0:0",
					},
					["name"] = "Bottomless Bag",
					[17] = {
						["C"] = 5,
						["L"] = "item:6149:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_73",
					},
					[18] = {
						["C"] = 3,
						["L"] = "item:6149:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_73",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[3] = {
					[1] = {
						["C"] = 199,
						["L"] = "item:17032:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Rune_08",
					},
					[2] = {
						["T"] = "Interface\\Icons\\Ability_Mount_Raptor",
						["L"] = "item:18790:0:0:0",
					},
					[3] = {
						["C"] = 171,
						["L"] = "item:17020:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Dust_01",
					},
					[4] = {
						["C"] = 122,
						["L"] = "item:21215:0:0:0",
						["T"] = "Interface\\Icons\\INV_Food_ChristmasFruitCake_01",
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Misc_QirajiCrystal_03",
						["L"] = "item:21323:0:0:0",
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Potion_83",
						["L"] = "item:22754:0:0:0",
					},
					[7] = {
						["C"] = 2,
						["L"] = "item:13444:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_76",
					},
					[8] = {
						["T"] = "Interface\\Icons\\INV_Misc_Cape_05",
						["L"] = "item:15138:0:0:0",
					},
					[9] = {
						["C"] = 37,
						["L"] = "item:8529:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_83",
					},
					[10] = {
						["T"] = "Interface\\Icons\\INV_Misc_Rune_01",
						["L"] = "item:6948:0:0:0",
					},
					[11] = {
						["T"] = "Interface\\Icons\\INV_Potion_41",
						["L"] = "item:13512:0:0:0",
					},
					[12] = {
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:10309:0:0:0",
					},
					[13] = {
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:10310:0:0:0",
					},
					[14] = {
						["C"] = 65,
						["L"] = "item:10308:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scroll_01",
					},
					[15] = {
						["C"] = 11,
						["L"] = "item:13446:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_54",
					},
					[16] = {
					},
					["name"] = "Bottomless Bag",
					[17] = {
					},
					[18] = {
						["C"] = 72,
						["L"] = "item:10306:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scroll_01",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[4] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_35",
						["L"] = "item:19109:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_13",
						["L"] = "item:19950:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_16",
						["L"] = "item:22433:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Wand_07",
						["L"] = "item:22408:0:0:0",
					},
					[5] = {
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Chest_Cloth_46",
						["L"] = "item:14340:0:0:0",
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Shoulder_02",
						["L"] = "item:11782:0:0:0",
					},
					[8] = {
					},
					[9] = {
						["T"] = "Interface\\Icons\\INV_Belt_29",
						["L"] = "item:11662:0:0:0",
					},
					[10] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_46",
						["L"] = "item:19893:0:0:0",
					},
					[11] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_AhnQiraj_03",
						["L"] = "item:21414:0:0:0",
					},
					[12] = {
						["T"] = "Interface\\Icons\\INV_Belt_02",
						["L"] = "item:3936:0:0:0",
					},
					[13] = {
						["T"] = "Interface\\Icons\\INV_Misc_AhnQirajTrinket_03",
						["L"] = "item:21647:0:0:0",
					},
					[14] = {
						["T"] = "Interface\\Icons\\INV_Chest_Cloth_03",
						["L"] = "item:16916:0:0:0",
					},
					[15] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_35",
						["L"] = "item:22339:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Talisman_07",
						["L"] = "item:12846:0:0:0",
					},
					["name"] = "Bottomless Bag",
					[17] = {
					},
					[18] = {
						["T"] = "Interface\\Icons\\INV_Boots_Fabric_01",
						["L"] = "item:22500:0:0:0",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[0] = {
					[1] = {
						["C"] = 2,
						["L"] = "item:8952:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Food_15",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_MonsterScales_07",
						["L"] = "item:15416:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01",
						["L"] = "item:8008:0:0:0",
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Opal_01",
						["L"] = "item:8007:0:0:0",
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Emerald_02",
						["L"] = "item:5513:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Emerald_01",
						["L"] = "item:5514:0:0:0",
					},
					["name"] = "Backpack",
					["Color"] = "ffffffff",
					["T"] = "Interface\\Buttons\\Button-Backpack-Up",
					["size"] = 16,
				},
				[-2] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Misc_Key_08",
						["L"] = "item:21761:0:0:0",
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					["name"] = "Keyring",
					["Color"] = "ffffffff",
					["T"] = "Interface\\ContainerFrame\\KeyRing-Bag-Icon",
					["size"] = 12,
				},
			},
			["Timestamp"] = 1516218369,
			["Data"] = {
				["Type"] = "Self",
				["Guild"] = {
					["Title"] = "Initiate",
					["GuildName"] = "Mining Company",
					["Rank"] = 4,
				},
				["Honor"] = {
					["HK"] = 0,
					["DK"] = 0,
				},
				["Money"] = 6645471,
				["CombatStats"] = {
					["P"] = 0,
					["C"] = "1.70",
					["D"] = 1.649999976158142,
				},
				["Basic"] = {
					["Defense"] = 300,
					["Health"] = 3540,
					["Armor"] = "826:826:0",
					["Mana"] = 5643,
				},
				["xp"] = {
					["current"] = 0,
					["max"] = 0,
					["timestamp"] = 1516218369,
					["resting"] = false,
				},
				["Location"] = {
					["SubZone"] = "",
					["Zone"] = "Hyjal",
				},
				["Resists"] = {
					[2] = 6,
					[3] = 6,
					[4] = 6,
					[5] = 51,
					[6] = 6,
				},
				["Mail"] = {
					["HasNewMail"] = false,
				},
				["Timestamp"] = 1516218369,
				["Id"] = {
					["ClassEn"] = "MAGE",
					["SexId"] = 0,
					["Race"] = "Undead",
					["Name"] = "Mevolent",
					["Sex"] = "Male",
					["Class"] = "Mage",
					["RaceEn"] = "Scourge",
					["Level"] = 60,
					["Server"] = "RetroWoW",
				},
				["Stats"] = {
					[1] = "29:29:0:0",
					[2] = "33:33:0:0",
					[3] = "46:236:190:0",
					[4] = "123:310:187:0",
					[5] = "125:163:38:0",
				},
			},
			["Bank"] = {
				[5] = {
					[1] = {
						["L"] = "item:21306:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Book_02",
					},
					[2] = {
						["L"] = "item:21304:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Book_02",
					},
					[4] = {
						["L"] = "item:18788:0:0:0",
						["T"] = "Interface\\Icons\\Ability_Mount_Raptor",
					},
					[5] = {
						["L"] = "item:21292:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_StoneTablet_11",
					},
					[6] = {
						["L"] = "item:21303:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Book_10",
					},
					[7] = {
						["L"] = "item:19160:0:0:0",
						["T"] = "Interface\\Icons\\INV_Shirt_GuildTabard_01",
					},
					[8] = {
						["L"] = "item:18797:0:0:0",
						["T"] = "Interface\\Icons\\Ability_Mount_WhiteDireWolf",
					},
					[9] = {
						["L"] = "item:18789:0:0:0",
						["T"] = "Interface\\Icons\\Ability_Mount_Raptor",
					},
					[11] = {
						["L"] = "item:13513:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_48",
					},
					[15] = {
						["L"] = "item:21206:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_40",
					},
					[16] = {
						["L"] = "item:21611:0:0:0",
						["T"] = "Interface\\Icons\\INV_Bracer_13",
					},
					["name"] = "Onyxia Hide Backpack",
					["L"] = "item:17966:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_22",
					["size"] = 18,
				},
				[6] = {
					[1] = {
						["L"] = "item:20932:0:0:0",
						["T"] = "Interface\\Icons\\INV_Qiraj_BindingsDominance",
					},
					[13] = {
						["C"] = 2,
						["T"] = "Interface\\Icons\\INV_Bracer_18",
						["L"] = "item:20926:0:0:0",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_08",
					[9] = {
						["C"] = 2,
						["T"] = "Interface\\Icons\\INV_Qiraj_HuskOldGod",
						["L"] = "item:20933:0:0:0",
					},
					[5] = {
						["L"] = "item:20890:0:0:0",
						["T"] = "Interface\\Icons\\INV_Qiraj_HiltOrnate",
					},
					["L"] = "item:4500:0:0:0",
					["name"] = "Traveler's Backpack",
					["size"] = 16,
				},
				["Main"] = {
				},
				["timestamp"] = 1516212762,
				[7] = {
					[1] = {
						["L"] = "item:21345:0:0:0",
						["T"] = "Interface\\Icons\\INV_Shoulder_03",
					},
					[2] = {
						["L"] = "item:16818:0:0:0",
						["T"] = "Interface\\Icons\\INV_Belt_22",
					},
					[3] = {
						["L"] = "item:19845:0:0:0",
						["T"] = "Interface\\Icons\\INV_Shoulder_17",
					},
					[4] = {
						["L"] = "item:19339:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Nature_WispHeal",
					},
					[5] = {
						["L"] = "item:19438:0:0:0",
						["T"] = "Interface\\Icons\\INV_Boots_Cloth_16",
					},
					[6] = {
						["L"] = "item:21347:0:0:0",
						["T"] = "Interface\\Icons\\INV_Helmet_06",
					},
					[7] = {
						["L"] = "item:19356:0:0:0",
						["T"] = "Interface\\Icons\\INV_Staff_06",
					},
					[8] = {
						["L"] = "item:20034:0:0:0",
						["T"] = "Interface\\Icons\\INV_Chest_Cloth_12",
					},
					[9] = {
						["L"] = "item:23545:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Shadow_DarkRitual",
					},
					[10] = {
						["L"] = "item:22937:0:0:0",
						["T"] = "Interface\\Icons\\INV_Offhand_Naxxramas_D_01",
					},
					[13] = {
						["L"] = "item:20749:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_105",
					},
					["name"] = "Traveler's Backpack",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_08",
					["L"] = "item:4500:0:0:0",
					["size"] = 16,
				},
			},
		},
		["Traubar"] = {
			["Equipment"] = {
				[1] = {
					["T"] = "Interface\\Icons\\INV_Helmet_36",
					["L"] = "item:12640:0:0:0",
				},
				[2] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_28Naxxramas",
					["L"] = "item:23053:0:0:0",
				},
				[3] = {
					["T"] = "Interface\\Icons\\INV_Shoulder_35",
					["L"] = "item:21330:2717:0:0",
				},
				[4] = {
					["T"] = "Interface\\Icons\\INV_Chest_Leather_04",
					["L"] = "item:6125:0:0:0",
				},
				[5] = {
					["T"] = "Interface\\Icons\\INV_Chest_Leather_02",
					["L"] = "item:23226:1892:0:0",
				},
				[6] = {
					["T"] = "Interface\\Icons\\INV_Belt_32",
					["L"] = "item:19823:0:0:0",
				},
				[7] = {
					["T"] = "Interface\\Icons\\INV_Pants_Plate_20",
					["L"] = "item:23068:0:0:0",
				},
				[8] = {
					["T"] = "Interface\\Icons\\INV_Boots_Plate_04",
					["L"] = "item:19387:911:0:0",
				},
				[9] = {
					["T"] = "Interface\\Icons\\INV_Bracer_13",
					["L"] = "item:21602:1885:0:0",
				},
				[10] = {
					["T"] = "Interface\\Icons\\INV_Gauntlets_17",
					["L"] = "item:21672:2564:0:0",
				},
				[11] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_48Naxxramas",
					["L"] = "item:23038:0:0:0",
				},
				[12] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_41",
					["L"] = "item:19384:0:0:0",
				},
				[13] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_TrinketPVP_02",
					["L"] = "item:18834:0:0:0",
				},
				[14] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Talisman_01",
					["L"] = "item:11815:0:0:0",
				},
				[15] = {
					["T"] = "Interface\\Icons\\INV_Misc_Cape_06",
					["L"] = "item:18541:2621:0:0",
				},
				[16] = {
					["T"] = "Interface\\Icons\\INV_Sword_61",
					["L"] = "item:23054:1900:0:0",
				},
				[17] = {
					["T"] = "Interface\\Icons\\INV_Sword_62",
					["L"] = "item:23577:1900:0:0",
				},
				[18] = {
					["T"] = "Interface\\Icons\\INV_Weapon_Rifle_10",
					["L"] = "item:23557:0:0:0",
				},
				[19] = {
					["T"] = "Interface\\Icons\\INV_Shirt_GuildTabard_01",
					["L"] = "item:11364:0:0:0",
				},
			},
			["Bag"] = {
				[1] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Misc_Rune_01",
						["L"] = "item:6948:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Rune_09",
						["L"] = "item:22682:0:0:0",
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[2] = {
					[1] = {
						["C"] = 182,
						["T"] = "Interface\\Icons\\INV_Drink_04",
						["L"] = "item:21151:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Cape_05",
						["L"] = "item:15138:0:0:0",
					},
					[3] = {
						["C"] = 141,
						["T"] = "Interface\\Icons\\INV_Relics_TotemofRage",
						["L"] = "item:888002:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Misc_QirajiCrystal_01",
						["L"] = "item:21324:0:0:0",
					},
					[5] = {
						["C"] = 17,
						["T"] = "Interface\\Icons\\INV_Potion_54",
						["L"] = "item:13446:0:0:0",
					},
					[6] = {
						["C"] = 7,
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:10310:0:0:0",
					},
					[7] = {
						["C"] = 2,
						["T"] = "Interface\\Icons\\INV_Misc_Rune_07",
						["L"] = "item:20558:0:0:0",
					},
					[8] = {
						["C"] = 200,
						["T"] = "Interface\\Icons\\Ability_Hunter_CriticalShot",
						["L"] = "item:12654:0:0:0",
					},
					[9] = {
						["C"] = 189,
						["T"] = "Interface\\Icons\\INV_Food_ChristmasFruitCake_01",
						["L"] = "item:21215:0:0:0",
					},
					[10] = {
						["C"] = 22,
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:10309:0:0:0",
					},
					[11] = {
						["C"] = 184,
						["T"] = "Interface\\Icons\\INV_Misc_Rune_02",
						["L"] = "item:999990:0:0:0",
					},
					[12] = {
						["C"] = 199,
						["T"] = "Interface\\Icons\\INV_Ammo_Bullet_02",
						["L"] = "item:13377:0:0:0",
					},
					[13] = {
						["C"] = 111,
						["T"] = "Interface\\Icons\\INV_Potion_83",
						["L"] = "item:8529:0:0:0",
					},
					[14] = {
						["C"] = 25,
						["T"] = "Interface\\Icons\\INV_Scroll_07",
						["L"] = "item:10307:0:0:0",
					},
					[15] = {
						["C"] = 5,
						["T"] = "Interface\\Icons\\INV_Jewelry_Amulet_07",
						["L"] = "item:20559:0:0:0",
					},
					[16] = {
						["C"] = 5,
						["T"] = "Interface\\Icons\\INV_Potion_32",
						["L"] = "item:13452:0:0:0",
					},
					[17] = {
						["T"] = "Interface\\Icons\\INV_Potion_83",
						["L"] = "item:22754:0:0:0",
					},
					[18] = {
						["C"] = 42,
						["T"] = "Interface\\Icons\\INV_Scroll_07",
						["L"] = "item:10305:0:0:0",
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[3] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_39",
						["L"] = "item:19912:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\Ability_Mount_BlackDireWolf",
						["L"] = "item:12330:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Helmet_71",
						["L"] = "item:16963:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Chest_Plate16",
						["L"] = "item:16966:0:0:0",
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Belt_09",
						["L"] = "item:16960:0:0:0",
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Gauntlets_10",
						["L"] = "item:16964:0:0:0",
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_13",
						["L"] = "item:19948:0:0:0",
					},
					[8] = {
						["T"] = "Interface\\Icons\\INV_Boots_Plate_04",
						["L"] = "item:16862:0:0:0",
					},
					[9] = {
					},
					[10] = {
						["T"] = "Interface\\Icons\\INV_Shoulder_23",
						["L"] = "item:19394:0:0:0",
					},
					[11] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_40",
						["L"] = "item:21196:0:0:0",
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[4] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Weapon_Hand_03",
						["L"] = "item:23242:1900:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Gauntlets_26",
						["L"] = "item:19143:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_AhnQiraj_03",
						["L"] = "item:21506:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Belt_18",
						["L"] = "item:21692:0:0:0",
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Misc_Cape_10",
						["L"] = "item:21710:0:0:0",
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Bracer_19",
						["L"] = "item:16959:1886:0:0",
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Misc_TabardPVP_02",
						["L"] = "item:15197:0:0:0",
					},
					[8] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_AhnQiraj_03",
						["L"] = "item:21393:0:0:0",
					},
					[9] = {
						["T"] = "Interface\\Icons\\INV_Helmet_09",
						["L"] = "item:16542:0:0:0",
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
						["T"] = "Interface\\Icons\\INV_Shield_22",
						["L"] = "item:21485:0:0:0",
					},
					[13] = {
						["T"] = "Interface\\Icons\\INV_Weapon_Crossbow_06",
						["L"] = "item:21459:0:0:0",
					},
					[14] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Pearl_05",
						["L"] = "item:19341:0:0:0",
					},
					[15] = {
						["C"] = 20,
						["T"] = "Interface\\Icons\\INV_Potion_04",
						["L"] = "item:5634:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Misc_Token_ArgentDawn2",
						["L"] = "item:23206:0:0:0",
					},
					[17] = {
						["T"] = "Interface\\Icons\\INV_Misc_ArmorKit_09",
						["L"] = "item:13965:0:0:0",
					},
					[18] = {
						["T"] = "Interface\\Icons\\INV_Misc_AhnQirajTrinket_03",
						["L"] = "item:21647:0:0:0",
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[0] = {
					[1] = {
						["C"] = 3,
						["T"] = "Interface\\Icons\\INV_Scroll_01",
						["L"] = "item:10308:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Scroll_01",
						["L"] = "item:10306:0:0:0",
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Misc_Food_51",
						["L"] = "item:7974:0:0:0",
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					["name"] = "Backpack",
					["Color"] = "ffffffff",
					["T"] = "Interface\\Buttons\\Button-Backpack-Up",
					["size"] = 16,
				},
				[-2] = {
					[1] = {
						["C"] = 6,
						["T"] = "Interface\\Icons\\INV_Misc_Key_08",
						["L"] = "item:21761:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Key_03",
						["L"] = "item:13307:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Misc_Key_03",
						["L"] = "item:13303:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Misc_Key_03",
						["L"] = "item:13304:0:0:0",
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					["name"] = "Keyring",
					["Color"] = "ffffffff",
					["T"] = "Interface\\ContainerFrame\\KeyRing-Bag-Icon",
					["size"] = 12,
				},
			},
			["Type"] = "Self",
			["Timestamp"] = 1516213645,
			["Data"] = {
				["Type"] = "Self",
				["Guild"] = {
					["Title"] = "Officer",
					["GuildName"] = "Mining Company",
					["Rank"] = 1,
				},
				["Honor"] = {
					["rankNumber"] = 9,
					["HK"] = 2002,
					["rankName"] = "Centurion",
					["DK"] = 0,
				},
				["Money"] = 38142205,
				["CombatStats"] = {
					["P"] = 5.159999847412109,
					["C"] = "29.14",
					["B"] = 5.159999847412109,
					["D"] = 9.059999465942383,
				},
				["Stats"] = {
					[1] = "125:358:233:0",
					[2] = "75:178:103:0",
					[3] = "112:305:193:0",
					[4] = "25:41:16:0",
					[5] = "47:63:16:0",
				},
				["Id"] = {
					["ClassEn"] = "WARRIOR",
					["Class"] = "Warrior",
					["Race"] = "Tauren",
					["Name"] = "Traubar",
					["Sex"] = "Male",
					["SexId"] = 0,
					["RaceEn"] = "Tauren",
					["Level"] = 60,
					["Server"] = "RetroWoW",
				},
				["Mail"] = {
					["HasNewMail"] = false,
				},
				["Basic"] = {
					["Health"] = 4891,
					["Armor"] = "4230:4614:384",
					["Defense"] = 300,
				},
				["Location"] = {
					["SubZone"] = "",
					["Zone"] = "Hyjal",
				},
				["Timestamp"] = 1516213645,
				["Resists"] = {
					[2] = 27,
					[3] = 37,
					[4] = 27,
					[5] = 27,
					[6] = 27,
				},
				["xp"] = {
					["resting"] = false,
					["max"] = 0,
					["timestamp"] = 1516213645,
					["current"] = 0,
				},
			},
			["Bank"] = {
				[5] = {
					[1] = {
						["L"] = "item:16864:0:0:0",
						["T"] = "Interface\\Icons\\INV_Belt_09",
					},
					[2] = {
						["L"] = "item:18205:0:0:0",
						["T"] = "Interface\\Icons\\INV_Belt_12",
					},
					[7] = {
						["L"] = "item:19377:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_17",
					},
					[8] = {
						["L"] = "item:13053:0:0:0",
						["T"] = "Interface\\Icons\\INV_Sword_01",
					},
					[10] = {
						["L"] = "item:23244:0:0:0",
						["T"] = "Interface\\Icons\\INV_Helmet_09",
					},
					[11] = {
						["L"] = "item:13142:0:0:0",
						["T"] = "Interface\\Icons\\INV_Belt_33",
					},
					[12] = {
						["L"] = "item:23221:1900:0:0",
						["T"] = "Interface\\Icons\\INV_Mace_28",
					},
					[13] = {
						["L"] = "item:22873:0:0:0",
						["T"] = "Interface\\Icons\\INV_Pants_06",
					},
					[14] = {
						["L"] = "item:21814:1892:0:0",
						["T"] = "Interface\\Icons\\INV_Chest_Plate02",
					},
					[15] = {
						["L"] = "item:22808:0:0:0",
						["T"] = "Interface\\Icons\\INV_Mace_1H_Stratholme_D_01",
					},
					[16] = {
						["L"] = "item:18404:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_09",
					},
					["name"] = "Onyxia Hide Backpack",
					[17] = {
						["L"] = "item:22872:0:0:0",
						["T"] = "Interface\\Icons\\INV_Chest_Plate16",
					},
					[18] = {
						["L"] = "item:23243:0:0:0",
						["T"] = "Interface\\Icons\\INV_Shoulder_11",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_22",
					["L"] = "item:17966:0:0:0",
					["size"] = 18,
				},
				[6] = {
					[1] = {
						["L"] = "item:22354:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateShoulder",
					},
					[3] = {
						["L"] = "item:22671:0:0:0",
						["T"] = "Interface\\Icons\\INV_Bracer_07",
					},
					[4] = {
						["L"] = "item:23028:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_35",
					},
					[5] = {
						["L"] = "item:22358:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateBoots",
					},
					[6] = {
						["L"] = "item:22356:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateBelt",
					},
					[7] = {
						["L"] = "item:22669:0:0:0",
						["T"] = "Interface\\Icons\\INV_Chest_Chain_11",
					},
					[8] = {
						["L"] = "item:22670:0:0:0",
						["T"] = "Interface\\Icons\\INV_Gauntlets_28",
					},
					[9] = {
						["L"] = "item:22352:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlatePants",
					},
					[10] = {
						["L"] = "item:22355:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateBracer",
					},
					[12] = {
						["L"] = "item:23019:0:0:0",
						["T"] = "Interface\\Icons\\INV_Helmet_06",
					},
					[13] = {
						["L"] = "item:22349:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateChest",
					},
					[14] = {
						["L"] = "item:22353:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Desecrated_PlateHelm",
					},
					["name"] = "Traveler's Backpack",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_08",
					["L"] = "item:4500:0:0:0",
					["size"] = 16,
				},
				[7] = {
					[3] = {
						["L"] = "item:22637:0:0:0",
						["T"] = "Interface\\Icons\\INV_ZulGurubTrinket",
					},
					[4] = {
						["L"] = "item:22637:0:0:0",
						["T"] = "Interface\\Icons\\INV_ZulGurubTrinket",
					},
					[7] = {
						["L"] = "item:22637:0:0:0",
						["T"] = "Interface\\Icons\\INV_ZulGurubTrinket",
					},
					[8] = {
						["C"] = 2,
						["L"] = "item:300502:0:0:0",
						["T"] = "Interface\\Icons\\INV_Trinket_Naxxramas03",
					},
					[12] = {
						["L"] = "item:12846:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Talisman_07",
					},
					["name"] = "Traveler's Backpack",
					["L"] = "item:4500:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_08",
					["size"] = 16,
				},
				[8] = {
					[12] = {
						["C"] = 7,
						["L"] = "item:13510:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_62",
					},
					[13] = {
						["L"] = "item:23548:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Shadow_DeathPact",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_08",
					[15] = {
						["L"] = "item:13511:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_97",
					},
					[16] = {
						["C"] = 6,
						["L"] = "item:13513:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_48",
					},
					["name"] = "Traveler's Backpack",
					["L"] = "item:4500:0:0:0",
					[11] = {
						["C"] = 3,
						["L"] = "item:3928:0:0:0",
						["T"] = "Interface\\Icons\\INV_Potion_53",
					},
					["size"] = 16,
				},
				["Main"] = {
					[1] = {
						["T"] = "Interface\\Icons\\Ability_Mount_BlackDireWolf",
						["L"] = "item:18796:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\Ability_Mount_WhiteDireWolf",
						["L"] = "item:12351:0:0:0",
					},
					[3] = {
						["C"] = 20,
						["T"] = "Interface\\Icons\\INV_Fabric_PurpleFire_01",
						["L"] = "item:14047:0:0:0",
					},
					[4] = {
						["C"] = 20,
						["T"] = "Interface\\Icons\\INV_Fabric_PurpleFire_01",
						["L"] = "item:14047:0:0:0",
					},
					[5] = {
						["C"] = 20,
						["T"] = "Interface\\Icons\\INV_Fabric_PurpleFire_01",
						["L"] = "item:14047:0:0:0",
					},
					[6] = {
						["C"] = 20,
						["T"] = "Interface\\Icons\\INV_Fabric_PurpleFire_01",
						["L"] = "item:14047:0:0:0",
					},
					[7] = {
						["C"] = 13,
						["T"] = "Interface\\Icons\\INV_Fabric_PurpleFire_01",
						["L"] = "item:14047:0:0:0",
					},
					[24] = {
						["T"] = "Interface\\Icons\\INV_Misc_Bag_22",
						["L"] = "item:17966:0:0:0",
					},
				},
				[9] = {
					[12] = {
						["C"] = 2,
						["L"] = "item:20929:0:0:0",
						["T"] = "Interface\\Icons\\INV_Qiraj_CarapaceOldGod",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_22",
					["name"] = "Onyxia Hide Backpack",
					[15] = {
						["L"] = "item:20928:0:0:0",
						["T"] = "Interface\\Icons\\INV_Qiraj_BindingsCommand",
					},
					[16] = {
						["C"] = 39,
						["L"] = "item:22375:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_WartornScrap_Plate",
					},
					[17] = {
						["C"] = 3,
						["L"] = "item:21229:0:0:0",
						["T"] = "Interface\\Icons\\INV_ZulGurubTrinket",
					},
					[18] = {
						["L"] = "item:21618:0:0:0",
						["T"] = "Interface\\Icons\\INV_Bracer_02",
					},
					[14] = {
						["L"] = "item:22798:0:0:0",
						["T"] = "Interface\\Icons\\INV_Mace_25",
					},
					[10] = {
						["L"] = "item:17713:0:0:0",
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_17",
					},
					["L"] = "item:17966:0:0:0",
					[11] = {
						["L"] = "item:20927:0:0:0",
						["T"] = "Interface\\Icons\\INV_Qiraj_OuroHide",
					},
					["size"] = 18,
				},
				["timestamp"] = 1516213425,
			},
		},
	},
	["Public Test Realm"] = {
		["Mevolent"] = {
			["Equipment"] = {
				[1] = {
					["T"] = "Interface\\Icons\\INV_Crown_01",
					["L"] = "item:22498:0:0:0",
				},
				[2] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Necklace_29Naxxramas",
					["L"] = "item:23057:0:0:0",
				},
				[3] = {
					["T"] = "Interface\\Icons\\INV_Shoulder_25",
					["L"] = "item:22499:0:0:0",
				},
				[4] = {
					["T"] = "Interface\\Icons\\INV_Shirt_01",
					["L"] = "item:6096:0:0:0",
				},
				[5] = {
					["T"] = "Interface\\Icons\\INV_Chest_Cloth_43",
					["L"] = "item:22496:0:0:0",
				},
				[6] = {
					["T"] = "Interface\\Icons\\INV_Belt_12",
					["L"] = "item:22730:0:0:0",
				},
				[7] = {
					["T"] = "Interface\\Icons\\INV_Pants_08",
					["L"] = "item:23070:0:0:0",
				},
				[8] = {
					["T"] = "Interface\\Icons\\INV_Boots_Cloth_05",
					["L"] = "item:21600:0:0:0",
				},
				[9] = {
					["T"] = "Interface\\Icons\\INV_Bracer_13",
					["L"] = "item:21611:0:0:0",
				},
				[10] = {
					["T"] = "Interface\\Icons\\INV_Gauntlets_03",
					["L"] = "item:18808:0:0:0",
				},
				[11] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_48Naxxramas",
					["L"] = "item:23025:0:0:0",
				},
				[12] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_Ring_AhnQiraj_02",
					["L"] = "item:21709:0:0:0",
				},
				[13] = {
					["T"] = "Interface\\Icons\\INV_Misc_StoneTablet_11",
					["L"] = "item:18820:0:0:0",
				},
				[14] = {
					["T"] = "Interface\\Icons\\INV_Jewelry_TrinketPVP_02",
					["L"] = "item:18850:0:0:0",
				},
				[15] = {
					["T"] = "Interface\\Icons\\INV_Misc_Cape_Naxxramas_03",
					["L"] = "item:23050:0:0:0",
				},
				[16] = {
					["T"] = "Interface\\Icons\\INV_Staff_13",
					["L"] = "item:22800:0:0:0",
				},
				[18] = {
					["T"] = "Interface\\Icons\\INV_Wand_1H_Stratholme_D_02",
					["L"] = "item:22821:0:0:0",
				},
			},
			["Type"] = "Self",
			["Timestamp"] = 1513116575,
			["Data"] = {
				["Type"] = "Self",
				["Guild"] = {
					["Rank"] = 0,
				},
				["Honor"] = {
					["DK"] = 0,
					["HK"] = 0,
				},
				["Money"] = 129985013,
				["CombatStats"] = {
					["P"] = 0,
					["C"] = "0.00",
					["D"] = 0,
				},
				["Id"] = {
					["ClassEn"] = "MAGE",
					["Class"] = "Mage",
					["Race"] = "Undead",
					["Name"] = "Mevolent",
					["Sex"] = "Male",
					["SexId"] = 0,
					["RaceEn"] = "Scourge",
					["Level"] = 60,
					["Server"] = "Public Test Realm",
				},
				["Stats"] = {
					[1] = "29:29:0:0",
					[2] = "33:33:0:0",
					[3] = "46:256:210:0",
					[4] = "123:350:227:0",
					[5] = "125:142:17:0",
				},
				["Mail"] = {
					["HasNewMail"] = false,
				},
				["Basic"] = {
					["Defense"] = 1,
					["Health"] = 3740,
					["Armor"] = "869:869:0",
					["Mana"] = 6243,
				},
				["Location"] = {
					["SubZone"] = "",
					["Zone"] = "Hyjal",
				},
				["Timestamp"] = 1513116575,
				["Resists"] = {
					[2] = 0,
					[3] = 0,
					[4] = 0,
					[5] = 10,
					[6] = 0,
				},
				["xp"] = {
					["resting"] = false,
					["max"] = 0,
					["timestamp"] = 1513116575,
					["current"] = 0,
				},
			},
			["Bag"] = {
				[1] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[2] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[3] = {
					[1] = {
						["T"] = "Interface\\Icons\\Ability_Mount_Raptor",
						["L"] = "item:18789:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\Ability_Mount_Undeadhorse",
						["L"] = "item:13335:0:0:0",
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[4] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					[17] = {
					},
					[18] = {
					},
					["name"] = "Bottomless Bag",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[0] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Jewelry_Ring_23",
						["L"] = "item:16683:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Pants_06",
						["L"] = "item:16687:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Misc_Rune_01",
						["L"] = "item:6948:0:0:0",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Shirt_GuildTabard_01",
						["L"] = "item:19160:0:0:0",
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Boots_02",
						["L"] = "item:16682:0:0:0",
					},
					[6] = {
						["T"] = "Interface\\Icons\\INV_Chest_Cloth_25",
						["L"] = "item:16688:0:0:0",
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Crown_02",
						["L"] = "item:16686:0:0:0",
					},
					[8] = {
						["T"] = "Interface\\Icons\\INV_Shoulder_23",
						["L"] = "item:16689:0:0:0",
					},
					[9] = {
						["T"] = "Interface\\Icons\\INV_Staff_08",
						["L"] = "item:35:0:0:0",
					},
					[10] = {
						["T"] = "Interface\\Icons\\INV_Belt_08",
						["L"] = "item:16685:0:0:0",
					},
					[11] = {
						["T"] = "Interface\\Icons\\INV_Gauntlets_17",
						["L"] = "item:16684:0:0:0",
					},
					[12] = {
						["C"] = 19,
						["T"] = "Interface\\Icons\\INV_Drink_11",
						["L"] = "item:8078:0:0:0",
					},
					[13] = {
						["C"] = 18,
						["T"] = "Interface\\Icons\\INV_Misc_Food_33",
						["L"] = "item:8076:0:0:0",
					},
					[14] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Ruby_01",
						["L"] = "item:8008:0:0:0",
					},
					[15] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Emerald_02",
						["L"] = "item:5513:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Opal_01",
						["L"] = "item:8007:0:0:0",
					},
					["name"] = "Backpack",
					["Color"] = "ffffffff",
					["T"] = "Interface\\Buttons\\Button-Backpack-Up",
					["size"] = 16,
				},
				[-2] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					["name"] = "Keyring",
					["Color"] = "ffffffff",
					["T"] = "Interface\\ContainerFrame\\KeyRing-Bag-Icon",
					["size"] = 12,
				},
			},
		},
	},
}
CharactersViewerConfig = {
	["Bag_Location"] = 0,
	["version"] = 62,
	["Bag_Display"] = true,
	["BankBag_Display"] = true,
}
