
StatCompare_SaveVar = {
	["IsDressUpStat"] = 0,
	["enable"] = 1,
	["ItemCollection"] = {
	},
}
StatCompare_Info = {
}
