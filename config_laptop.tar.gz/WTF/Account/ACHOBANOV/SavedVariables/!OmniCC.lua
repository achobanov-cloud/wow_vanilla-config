
OmniCC = {
	["min"] = 3,
	["font"] = "Fonts\\FRIZQT__.TTF",
	["short"] = {
		["r"] = 1,
		["g"] = 0,
		["b"] = 0,
	},
	["size"] = 20,
	["long"] = {
		["r"] = 0.8,
		["g"] = 0.8,
		["b"] = 0.9,
	},
	["medium"] = {
		["r"] = 1,
		["g"] = 1,
		["b"] = 0.4,
	},
}
