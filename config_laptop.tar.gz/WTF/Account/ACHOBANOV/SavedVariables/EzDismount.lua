
EzDismount_Config = {
	["Mevolent of RetroWoW"] = {
		["Stand"] = "ON",
		["Dismount"] = "ON",
		["Auction"] = "ON",
		["Shadowform"] = "ON",
		["Wolf"] = "ON",
		["Druid"] = "ON",
		["Moonkin"] = "ON",
	},
	["Traubar of RetroWoW"] = {
		["Stand"] = "ON",
		["Dismount"] = "ON",
		["Auction"] = "ON",
		["Shadowform"] = "OFF",
		["Wolf"] = "OFF",
		["Druid"] = "OFF",
		["Moonkin"] = "OFF",
	},
	["Mevolent of Public Test Realm"] = {
		["Stand"] = "ON",
		["Dismount"] = "ON",
		["Druid"] = "ON",
		["Shadowform"] = "ON",
		["Wolf"] = "ON",
		["Auction"] = "ON",
		["Moonkin"] = "ON",
	},
}
