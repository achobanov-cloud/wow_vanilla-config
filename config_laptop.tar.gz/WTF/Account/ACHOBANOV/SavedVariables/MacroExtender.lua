
MacroExtender_Options = {
	["Inventory"] = true,
	["ActionBars"] = true,
	["MacroUI"] = true,
}
