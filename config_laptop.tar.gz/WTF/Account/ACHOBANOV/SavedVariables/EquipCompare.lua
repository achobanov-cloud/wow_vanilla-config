
EquipCompare_Enabled = true
EquipCompare_ControlMode = false
EquipCompare_UseCV = true
EquipCompare_AltMode = false
EquipCompare_Shiftup = false
