
SM_VARS = {
	["macroTip1"] = 1,
	["printColor"] = {
		["r"] = 1,
		["g"] = 1,
		["b"] = 1,
	},
	["replaceIcon"] = 0,
	["minimap"] = 1,
	["hideAction"] = 0,
	["checkCooldown"] = 1,
	["tabShown"] = "regular",
	["macroTip2"] = 1,
}
SM_EXTEND = {
}
SM_ACTION_SUPER = {
	["Traubar of RetroWoW"] = {
	},
}
SM_SUPER = {
}
