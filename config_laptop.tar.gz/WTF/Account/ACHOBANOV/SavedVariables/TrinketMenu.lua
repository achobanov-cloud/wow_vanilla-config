
TrinketMenuOptions = {
	["Notify"] = "ON",
	["KeepOpen"] = "ON",
	["ShowIcon"] = "ON",
	["NotifyChatAlso"] = "OFF",
	["Locked"] = "ON",
	["MenuOnShift"] = "ON",
	["CooldownCount"] = "ON",
	["TooltipFollow"] = "OFF",
	["IconPos"] = -20.04100452928544,
	["NotifyUsedOnly"] = "OFF",
	["NotifyThirty"] = "OFF",
	["DisableToggle"] = "OFF",
	["ShowTooltips"] = "ON",
	["SquareMinimap"] = "OFF",
	["KeepDocked"] = "ON",
}
