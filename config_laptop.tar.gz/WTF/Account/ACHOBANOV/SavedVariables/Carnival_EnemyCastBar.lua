
Carnival_EnemyCastBar = {
	["bTimer"] = true,
	["bLocked"] = true,
	["bPvE"] = true,
	["bPvP"] = true,
	["bDebug"] = true,
	["bStatus"] = true,
}
