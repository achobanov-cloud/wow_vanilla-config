
SCT_ManaGain_Saved = nil
