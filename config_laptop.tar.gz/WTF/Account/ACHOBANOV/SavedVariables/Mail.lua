
Mail_AutoCompleteNames = {
	["RetroWoW|Horde"] = {
		["Bankes"] = 6293.078,
		["Mevolent"] = 2585.484,
		["Traubar"] = 6299.875,
	},
}
