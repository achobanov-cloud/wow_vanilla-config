
AtlasLootOptions = {
	["EquipCompare"] = false,
	["AllLinks"] = false,
	["ItemSyncTT"] = false,
	["DefaultTT"] = true,
	["SafeLinks"] = true,
	["LootlinkTT"] = false,
}
AtlasLootVersion = nil
