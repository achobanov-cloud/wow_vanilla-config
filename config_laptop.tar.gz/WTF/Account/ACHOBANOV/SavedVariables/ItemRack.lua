
ItemRack_Users = {
	["Mevolent of RetroWoW"] = {
		["Visible"] = "OFF",
		["MainScale"] = 1,
		["XPos"] = 400,
		["Sets"] = {
		},
		["Ignore"] = {
		},
		["Inv"] = {
		},
		["Events"] = {
		},
		["MainOrient"] = "HORIZONTAL",
		["Locked"] = "OFF",
		["YPos"] = 350,
		["Spaces"] = {
		},
		["Bar"] = {
		},
	},
	["Traubar of RetroWoW"] = {
		["Visible"] = "OFF",
		["MainScale"] = 1,
		["XPos"] = 386.2917100099292,
		["Sets"] = {
		},
		["Ignore"] = {
		},
		["Inv"] = {
		},
		["Events"] = {
		},
		["MainOrient"] = "VERTICAL",
		["Locked"] = "OFF",
		["YPos"] = 348.2864547241255,
		["Spaces"] = {
		},
		["Bar"] = {
		},
	},
	["Mevolent of Public Test Realm"] = {
		["Visible"] = "OFF",
		["MainScale"] = 1,
		["XPos"] = 400,
		["Sets"] = {
		},
		["Ignore"] = {
		},
		["Inv"] = {
		},
		["Events"] = {
		},
		["MainOrient"] = "HORIZONTAL",
		["Locked"] = "OFF",
		["YPos"] = 350,
		["Spaces"] = {
		},
		["Bar"] = {
		},
	},
}
ItemRack_Settings = {
	["Notify"] = "OFF",
	["AllowHidden"] = "OFF",
	["Minimap"] = {
	},
	["ShowAllEvents"] = "OFF",
	["MenuShift"] = "ON",
	["Soulbound"] = "OFF",
	["EnableEvents"] = "OFF",
	["RotateMenu"] = "ON",
	["AutoToggle"] = "OFF",
	["BigCooldown"] = "OFF",
	["LargeFont"] = "OFF",
	["ShowIcon"] = "ON",
	["Bindings"] = "ON",
	["TooltipFollow"] = "ON",
	["IconPos"] = 8.159426528896788,
	["SetLabels"] = "ON",
	["ShowTooltips"] = "OFF",
	["NotifyThirty"] = "ON",
	["FlipBar"] = "OFF",
	["FlipMenu"] = "OFF",
	["TinyTooltip"] = "OFF",
	["DisableToggle"] = "ON",
	["RightClick"] = "ON",
	["CompactList"] = "OFF",
	["CooldownNumbers"] = "ON",
	["SquareMinimap"] = "OFF",
	["ShowEmpty"] = "ON",
}
ItemRack_Events = {
	["Druid:Caster Form"] = {
		["script"] = "if not ItemRack_GetForm() and IR_FORM then EquipSet() IR_FORM=nil end --[[Equip a set when not in an animal form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Druid:Aquatic Form"] = {
		["script"] = "local form=ItemRack_GetForm() if form==\"Aquatic Form\" and IR_FORM~=form then EquipSet() IR_FORM=form end --[[Equip a set when in aquatic form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Druid:Moonkin Form"] = {
		["script"] = "local form=ItemRack_GetForm() if form==\"Moonkin Form\" and IR_FORM~=form then EquipSet() IR_FORM=form end --[[Equip a set when in moonkin form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["events_version"] = 1.975,
	["Plaguelands"] = {
		["script"] = "local zone = GetRealZoneText(),0\nif (zone==\"Western Plaguelands\" or zone==\"Eastern Plaguelands\" or zone==\"Scholomance\" or zone==\"Stratholme\") and not IR_PLAGUE then\n    EquipSet() IR_PLAGUE=1\nelseif IR_PLAGUE then\n    LoadSet() IR_PLAGUE=nil\nend\n--[[Equips set to be worn while in plaguelands.]]",
		["trigger"] = "ZONE_CHANGED_NEW_AREA",
		["delay"] = 1,
	},
	["About Town"] = {
		["script"] = "if IsResting() and not IR_TOWN then EquipSet() IR_TOWN=1 elseif IR_TOWN then LoadSet() IR_TOWN=nil end\n--[[Equips a set while in a city or inn.]]",
		["trigger"] = "PLAYER_UPDATE_RESTING",
		["delay"] = 0,
	},
	["Druid:Cat Form"] = {
		["script"] = "local form=ItemRack_GetForm() if form==\"Cat Form\" and IR_FORM~=form then EquipSet() IR_FORM=form end --[[Equip a set when in cat form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Low Mana"] = {
		["script"] = "local mana = UnitMana(\"player\") / UnitManaMax(\"player\")\nif mana < .5 and not IR_OOM then\n  SaveSet()\n  EquipSet()\n  IR_OOM = 1\nelseif IR_OOM and mana > .75 then\n  LoadSet()\n  IR_OOM = nil\nend\n--[[Equips a set when mana is below 50% and re-equips previous gear at 75% mana. Remember: You can't swap non-weapons in combat.]]",
		["trigger"] = "UNIT_MANA",
		["delay"] = 0.5,
	},
	["Rogue:Stealth"] = {
		["script"] = "local _,_,isActive = GetShapeshiftFormInfo(1)\nif isActive and not IR_FORM then\n  EquipSet() IR_FORM=1\nelseif not isActive and IR_FORM then\n  LoadSet() IR_FORM=nil\nend\n--[[Equips set to be worn while stealthed.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Mage:Evocation"] = {
		["script"] = "local evoc=arg1[\"Interface\\\\Icons\\\\Spell_Nature_Purge\"]\nif evoc and not IR_EVOC then\n  EquipSet() IR_EVOC=1\nelseif not evoc and IR_EVOC then\n  LoadSet() IR_EVOC=nil\nend\n--[[Equips a set to wear while channeling Evocation.]]",
		["trigger"] = "ITEMRACK_BUFFS_CHANGED",
		["delay"] = 0.25,
	},
	["Warrior:Berserker"] = {
		["script"] = "local _,_,isActive = GetShapeshiftFormInfo(3) if isActive and IR_FORM~=\"Berserker\" then EquipSet() IR_FORM=\"Berserker\" end --[[Equips set to be worn in Berserker stance.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Druid:Bear Form"] = {
		["script"] = "local form = ItemRack_GetForm()\nif (form==\"Dire Bear Form\" or form==\"Bear Form\") and IR_FORM~=\"Bear Form\" then EquipSet() IR_FORM=\"Bear Form\" end --[[Equip a set when in bear form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Warrior:Battle"] = {
		["script"] = "local _,_,isActive = GetShapeshiftFormInfo(1) if isActive and IR_FORM~=\"Battle\" then EquipSet() IR_FORM=\"Battle\" end --[[Equips set to be worn in battle stance.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Skinning"] = {
		["script"] = "if UnitIsDead(\"mouseover\") and GameTooltipTextLeft3:GetText()==UNIT_SKINNABLE then\n  local r,g,b = GameTooltipTextLeft3:GetTextColor()\n  if r>.9 and g<.2 and b<.2 and not IR_SKIN then\n    EquipSet() IR_SKIN=1\n  end\nelseif IR_SKIN then\n  LoadSet() IR_SKIN=nil\nend\n--[[Equips a set when you mouseover something that can be skinned but you have insufficient skill.]]\n",
		["trigger"] = "UPDATE_MOUSEOVER_UNIT",
		["delay"] = 0,
	},
	["Warrior:Overpower End"] = {
		["script"] = "--[[Equip a set five seconds after opponent dodged: your normal weapons. ]]\nif IR_OVERPOWER==1 then\nEquipSet()\nIR_OVERPOWER=nil\nend",
		["trigger"] = "CHAT_MSG_COMBAT_SELF_MISSES",
		["delay"] = 5,
	},
	["Warrior:Overpower Begin"] = {
		["script"] = "--[[Equip a set when the opponent dodges.  Associate a heavy-hitting 2h set with this event. ]]\nlocal _,_,i = GetShapeshiftFormInfo(1)\nif string.find(arg1 or \"\",\"^You.+dodge[sd]\") and i then\nEquipSet()\nIR_OVERPOWER=1\nend",
		["trigger"] = "CHAT_MSG_COMBAT_SELF_MISSES",
		["delay"] = 0,
	},
	["Insignia Used"] = {
		["script"] = "if arg1==\"Insignia of the Alliance\" or arg1==\"Insignia of the Horde\" then EquipSet() end --[[Equips a set when the Insignia of the Alliance/Horde has been used.]]",
		["trigger"] = "ITEMRACK_ITEMUSED",
		["delay"] = 0.5,
	},
	["Swimming"] = {
		["script"] = "local i,found\nfor i=1,3 do\n  if getglobal(\"MirrorTimer\"..i):IsVisible() and getglobal(\"MirrorTimer\"..i..\"Text\"):GetText() == BREATH_LABEL then\n    found = 1\n  end\nend\nif found then\n  EquipSet()\nend\n--[[Equips a set when the breath gauge appears. NOTE: This will not re-equip gear when you leave water.  There's no reliable way to know when you leave water. Also note: Won't work with eCastingBar.]]",
		["trigger"] = "MIRROR_TIMER_START",
		["delay"] = 0,
	},
	["Warrior:Defensive"] = {
		["script"] = "local _,_,isActive = GetShapeshiftFormInfo(2) if isActive and IR_FORM~=\"Defensive\" then EquipSet() IR_FORM=\"Defensive\" end --[[Equips set to be worn in Defensive stance.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Priest:Spirit Tap Begin"] = {
		["script"] = "local found=ItemRack.Buffs[\"Interface\\\\Icons\\\\Spell_Shadow_Requiem\"]\nif not IR_SPIRIT and found then\nEquipSet() IR_SPIRIT=1\nend\n--[[Equips a set when you leave combat with Spirit Tap. Associate a set of spirit gear to this event.]]",
		["trigger"] = "PLAYER_REGEN_ENABLED",
		["delay"] = 0.25,
	},
	["Insignia"] = {
		["script"] = "if arg1==\"Insignia of the Alliance\" or arg1==\"Insignia of the Horde\" then EquipSet() end --[[Equips a set when the Insignia of the Alliance/Horde finishes cooldown.]]",
		["trigger"] = "ITEMRACK_NOTIFY",
		["delay"] = 0,
	},
	["Eating-Drinking"] = {
		["script"] = "local found=arg1[\"Interface\\\\Icons\\\\INV_Misc_Fork&Knife\"] or arg1[\"Drink\"]\nif not IR_DRINK and found then\nEquipSet() IR_DRINK=1\nelseif IR_DRINK and not found then\nLoadSet() IR_DRINK=nil\nend\n--[[Equips a set while eating or drinking.]]",
		["trigger"] = "ITEMRACK_BUFFS_CHANGED",
		["delay"] = 0,
	},
	["Mount"] = {
		["script"] = "local mount\nif UnitIsMounted then mount = UnitIsMounted(\"player\") else mount = ItemRack_PlayerMounted() end\nif not IR_MOUNT and mount then\n  EquipSet()\nelseif IR_MOUNT and not mount then\n  LoadSet()\nend\nIR_MOUNT=mount\n--[[Equips set to be worn while mounted.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Druid:Travel Form"] = {
		["script"] = "local form=ItemRack_GetForm() if form==\"Travel Form\" and IR_FORM~=form then EquipSet() IR_FORM=form end --[[Equip a set when in travel form.]]",
		["trigger"] = "PLAYER_AURAS_CHANGED",
		["delay"] = 0,
	},
	["Priest:Shadowform"] = {
		["script"] = "local f=arg1[\"Interface\\\\Icons\\\\Spell_Shadow_Shadowform\"]\nif not IR_Shadowform and f then\n  EquipSet() IR_Shadowform=1\nelseif IR_Shadowform and not f then\n  LoadSet() IR_Shadowform=nil\nend\n--[[Equips a set while under Shadowform]]",
		["trigger"] = "ITEMRACK_BUFFS_CHANGED",
		["delay"] = 0,
	},
	["Priest:Spirit Tap End"] = {
		["script"] = "local found=arg1[\"Interface\\\\Icons\\\\Spell_Shadow_Requiem\"]\nif IR_SPIRIT and not found then\nLoadSet() IR_SPIRIT = nil\nend\n--[[Returns to normal gear when Spirit Tap ends. Associate the same spirit set as Spirit Tap Begin.]]",
		["trigger"] = "ITEMRACK_BUFFS_CHANGED",
		["delay"] = 0.5,
	},
}
Rack_User = {
	["Mevolent of RetroWoW"] = {
		["Sets"] = {
			["Rack-CombatQueue"] = {
				[1] = {
				},
				[2] = {
				},
				[3] = {
				},
				[4] = {
				},
				[5] = {
				},
				[6] = {
				},
				[7] = {
				},
				[8] = {
				},
				[9] = {
				},
				[10] = {
				},
				[11] = {
				},
				[12] = {
				},
				[13] = {
				},
				[14] = {
				},
				[15] = {
				},
				[16] = {
				},
				[17] = {
				},
				[18] = {
				},
				[19] = {
				},
				[0] = {
				},
			},
		},
	},
	["Traubar of RetroWoW"] = {
		["Sets"] = {
			["Fury"] = {
				[1] = {
					["id"] = "12640:0:0",
					["name"] = "Lionheart Helm",
				},
				[2] = {
					["id"] = "19377:0:0",
					["name"] = "Prestor's Talisman of Connivery",
				},
				[3] = {
					["id"] = "21330:2717:0",
					["name"] = "Conqueror's Spaulders",
				},
				[4] = {
					["id"] = "6125:0:0",
					["name"] = "Brawler's Harness",
				},
				[5] = {
					["id"] = "23226:1892:0",
					["name"] = "Ghoul Skin Tunic",
				},
				[6] = {
					["id"] = "19823:0:0",
					["name"] = "Zandalar Vindicator's Belt",
				},
				[7] = {
					["id"] = "22873:0:0",
					["name"] = "Legionnaire's Plate Leggings",
				},
				[8] = {
					["id"] = "19387:0:0",
					["name"] = "Chromatic Boots",
				},
				[9] = {
					["id"] = "21602:1885:0",
					["name"] = "Qiraji Execution Bracers",
				},
				[10] = {
					["id"] = "21672:2564:0",
					["name"] = "Gloves of Enforcement",
				},
				[11] = {
					["id"] = "19384:0:0",
					["name"] = "Master Dragonslayer's Ring",
				},
				[12] = {
					["id"] = "21393:0:0",
					["name"] = "Signet of Unyielding Strength",
				},
				[13] = {
					["id"] = "13965:0:0",
					["name"] = "Blackhand's Breadth",
				},
				[14] = {
					["id"] = "11815:0:0",
					["name"] = "Hand of Justice",
				},
				[15] = {
					["id"] = "18541:2621:0",
					["name"] = "Puissant Cape",
				},
				[16] = {
					["id"] = "23221:1900:0",
					["name"] = "Misplaced Servo Arm",
				},
				[18] = {
					["id"] = "23557:0:0",
					["name"] = "Larvae of the Great Worm",
				},
				[19] = {
					["id"] = "15197:0:0",
					["name"] = "Scout's Tabard",
				},
				["showcloak"] = 1,
				["icon"] = "Interface\\Icons\\INV_Helmet_01",
				["showhelm"] = 1,
			},
			["Fury PvP"] = {
				[1] = {
					["id"] = "23244:0:0",
					["name"] = "Champion's Plate Helm",
				},
				[2] = {
					["id"] = "21506:0:0",
					["name"] = "Pendant of the Shifting Sands",
				},
				[3] = {
					["id"] = "21330:2717:0",
					["name"] = "Conqueror's Spaulders",
				},
				[4] = {
					["id"] = "6125:0:0",
					["name"] = "Brawler's Harness",
				},
				[5] = {
					["id"] = "23226:0:0",
					["name"] = "Ghoul Skin Tunic",
				},
				[6] = {
					["id"] = "21692:0:0",
					["name"] = "Triad Girdle",
				},
				[7] = {
					["id"] = "22873:0:0",
					["name"] = "Legionnaire's Plate Leggings",
				},
				[8] = {
					["id"] = "16734:0:0",
					["name"] = "Boots of Valor",
				},
				[9] = {
					["id"] = "16959:0:0",
					["name"] = "Bracelets of Wrath",
				},
				[10] = {
					["id"] = "19143:0:0",
					["name"] = "Flameguard Gauntlets",
				},
				[11] = {
					["id"] = "21393:0:0",
					["name"] = "Signet of Unyielding Strength",
				},
				[12] = {
					["id"] = "18522:0:0",
					["name"] = "Band of the Ogre King",
				},
				[13] = {
					["id"] = "18834:0:0",
					["name"] = "Insignia of the Horde",
				},
				[14] = {
					["id"] = "11815:0:0",
					["name"] = "Hand of Justice",
				},
				[15] = {
					["id"] = "17107:0:0",
					["name"] = "Dragon's Blood Cape",
				},
				[16] = {
					["id"] = "23577:1900:0",
					["name"] = "The Hungering Cold",
				},
				[18] = {
					["id"] = "21459:0:0",
					["name"] = "Crossbow of Imminent Doom",
				},
				[19] = {
					["id"] = "15197:0:0",
					["name"] = "Scout's Tabard",
				},
				["icon"] = "Interface\\Icons\\INV_Jewelry_TrinketPVP_02",
			},
			["Arms"] = {
				[1] = {
					["name"] = "Champion's Plate Helm",
					["id"] = "23244:0:0",
					["old"] = "22411:0:0",
				},
				[2] = {
					["id"] = "18404:0:0",
					["name"] = "Onyxia Tooth Pendant",
				},
				[3] = {
					["id"] = "23243:0:0",
					["name"] = "Champion's Plate Shoulders",
				},
				[4] = {
					["id"] = "6125:0:0",
					["name"] = "Brawler's Harness",
				},
				[5] = {
					["id"] = "22872:0:0",
					["name"] = "Legionnaire's Plate Hauberk",
				},
				[6] = {
					["id"] = "13142:0:0",
					["name"] = "Brigam Girdle",
				},
				[7] = {
					["id"] = "22873:0:0",
					["name"] = "Legionnaire's Plate Leggings",
				},
				[8] = {
					["id"] = "16734:0:0",
					["name"] = "Boots of Valor",
				},
				[9] = {
					["name"] = "Vambraces of the Sadist",
					["id"] = "13400:0:0",
					["old"] = "12936:0:0",
				},
				[10] = {
					["id"] = "22714:0:0",
					["name"] = "Sacrificial Gauntlets",
				},
				[11] = {
					["name"] = "Painweaver Band",
					["id"] = "13098:0:0",
					["old"] = "17713:0:0",
				},
				[12] = {
					["id"] = "18522:0:0",
					["name"] = "Band of the Ogre King",
				},
				[13] = {
					["name"] = "Hand of Justice",
					["id"] = "11815:0:0",
					["old"] = "13965:0:0",
				},
				[14] = {
					["name"] = "Blackhand's Breadth",
					["id"] = "13965:0:0",
					["old"] = "11815:0:0",
				},
				[15] = {
					["id"] = "13397:0:0",
					["name"] = "Stoneskin Gargoyle Cape",
				},
				[16] = {
					["name"] = "Kalimdor's Revenge",
					["id"] = "21679:0:0",
					["old"] = "19852:0:0",
				},
				[17] = {
					["id"] = 0,
				},
				[18] = {
					["id"] = "12651:0:0",
					["name"] = "Blackcrow",
				},
				[19] = {
					["id"] = "15197:0:0",
					["name"] = "Scout's Tabard",
				},
				["key"] = "UP",
				["oldsetname"] = "Arms",
				["keyindex"] = 1,
				["showcloak"] = 1,
				["icon"] = "Interface\\Icons\\INV_Sword_56",
				["showhelm"] = 1,
			},
			["Rack-CombatQueue"] = {
				[1] = {
				},
				[2] = {
				},
				[3] = {
				},
				[4] = {
				},
				[5] = {
				},
				[6] = {
				},
				[7] = {
				},
				[8] = {
				},
				[9] = {
				},
				[10] = {
				},
				[11] = {
				},
				[12] = {
				},
				[13] = {
				},
				[14] = {
				},
				[15] = {
				},
				[16] = {
				},
				[17] = {
				},
				[18] = {
				},
				[19] = {
				},
				[0] = {
				},
			},
		},
		["CurrentSet"] = "Fury",
	},
	["Mevolent of Public Test Realm"] = {
		["Sets"] = {
			["Rack-CombatQueue"] = {
				[1] = {
				},
				[2] = {
				},
				[3] = {
				},
				[4] = {
				},
				[5] = {
				},
				[6] = {
				},
				[7] = {
				},
				[8] = {
				},
				[9] = {
				},
				[10] = {
				},
				[11] = {
				},
				[12] = {
				},
				[13] = {
				},
				[14] = {
				},
				[15] = {
				},
				[16] = {
				},
				[17] = {
				},
				[18] = {
				},
				[19] = {
				},
				[0] = {
				},
			},
		},
	},
}
