
TrinketMenuPerOptions = {
	["Visible"] = "ON",
	["MainScale"] = 1,
	["XPos"] = 400.0000054709792,
	["MainOrient"] = "HORIZONTAL",
	["MenuDock"] = "BOTTOMLEFT",
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 400.0000054709792,
	["MenuScale"] = 1,
	["MenuOrient"] = "VERTICAL",
}