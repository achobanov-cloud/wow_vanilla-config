
TrinketMenuPerOptions = {
	["Visible"] = "OFF",
	["MainScale"] = 0.8306148052215576,
	["XPos"] = 1455.28605800975,
	["MainOrient"] = "HORIZONTAL",
	["MenuDock"] = "BOTTOMLEFT",
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 310.3449254035411,
	["MenuScale"] = 0.8307647109031677,
	["MenuOrient"] = "VERTICAL",
}