
defcritCount = 0
speccritCount = 0
players = {
}
playersTaken = {
}
defCrits = {
	[1] = 0,
}
specCrits = {
	[1] = 0,
}
defCritTotals = {
}
specCritTotals = {
}
totalDamage = 0
overallCombatTime = 0
overallSwings = 0
overallMisses = 0
overallDodged = 0
overallParried = 0
overallEvaded = 0
overallBlocked = 0
overallResisted = 0
overallImmuned = 0
overallDeflected = 0
overallHits = 0
overallNonCrits = 0
overallCrits = 0
overallmaxCrit = 0
overallminCrit = 0
overallmaxReg = 0
overallminReg = 0
overallRegDmg = 0
overallCritDmg = 0
overallLastcrit = 0
attackNames = {
}
specialAttacks = {
}
specialAttackLog = {
}
totalHits = 0
totalCrits = 0
specialsCount = 0
CombatStats_Config = {
	["CombatStats_OnOff"] = 1,
	["CombatStats_HideOnNoTarget"] = 0,
	["CombatStats_UseMouseOver"] = 0,
	["CombatStats_EndOfFight"] = 0,
}