
StatCompare_Player = {
	["Settings"] = {
	},
}