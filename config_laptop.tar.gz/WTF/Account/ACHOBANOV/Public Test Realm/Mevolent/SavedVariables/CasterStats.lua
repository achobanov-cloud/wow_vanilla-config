
reportThis = 0