
TrinketMenuPerOptions = {
	["Visible"] = "ON",
	["MainScale"] = 1,
	["XPos"] = 400,
	["MainOrient"] = "HORIZONTAL",
	["MenuScale"] = 1,
	["MainDock"] = "BOTTOMRIGHT",
	["YPos"] = 400,
	["MenuDock"] = "BOTTOMLEFT",
	["MenuOrient"] = "VERTICAL",
}