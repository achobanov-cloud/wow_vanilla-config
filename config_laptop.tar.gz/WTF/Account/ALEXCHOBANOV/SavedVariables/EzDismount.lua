
EzDismount_Config = {
	["Bankes of RetroWoW"] = {
		["Stand"] = "ON",
		["Dismount"] = "ON",
		["Auction"] = "ON",
		["Shadowform"] = "ON",
		["Wolf"] = "ON",
		["Druid"] = "ON",
		["Moonkin"] = "ON",
	},
}
