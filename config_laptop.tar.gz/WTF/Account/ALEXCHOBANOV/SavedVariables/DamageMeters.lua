
DamageMeters_tables = {
	[1] = {
	},
	[2] = {
	},
	[3] = {
	},
}
DamageMeters_barCount = 10
DamageMeters_quantity = 1
DamageMeters_sort = 1
DamageMeters_textOptions = {
	[1] = false,
	[2] = true,
	[3] = false,
	[4] = false,
}
DamageMeters_colorScheme = 2
DamageMeters_autoCountLimit = 0
DamageMeters_syncChannel = nil
DamageMeters_loadedDataVersion = 5110
DamageMeters_pauseState = 0
DamageMeters_quantityColor = {
	[1] = {
		[1] = 1,
		[2] = 0,
		[3] = 0,
		[4] = 0.8,
	},
	[2] = {
		[1] = 0,
		[2] = 1,
		[3] = 0,
		[4] = 0.8,
	},
	[3] = {
		[1] = 1,
		[2] = 0.5,
		[3] = 0,
		[4] = 0.8,
	},
	[4] = {
		[1] = 0,
		[2] = 0,
		[3] = 1,
		[4] = 0.8,
	},
	[5] = {
		[1] = 0.6,
		[2] = 0.7,
		[3] = 0.8,
		[4] = 0.8,
	},
	[6] = {
		[1] = 1,
		[2] = 1,
		[3] = 0,
		[4] = 0.8,
	},
	[7] = {
		[1] = 1,
		[2] = 0,
		[3] = 1,
		[4] = 0.8,
	},
	[8] = {
		[1] = 0.8,
		[2] = 0,
		[3] = 0,
		[4] = 0.8,
	},
	[9] = {
		[1] = 0,
		[2] = 0.8,
		[3] = 0,
		[4] = 0.8,
	},
	[10] = {
		[1] = 1,
		[2] = 0.7,
		[3] = 0.2,
		[4] = 0.8,
	},
	[11] = {
		[1] = 0,
		[2] = 0,
		[3] = 0.8,
		[4] = 0.8,
	},
	[12] = {
		[1] = 0.4,
		[2] = 0.5,
		[3] = 0.6,
		[4] = 0.8,
	},
	[13] = {
		[1] = 0.4,
		[2] = 0.4,
		[3] = 0,
		[4] = 0.8,
	},
	[14] = {
		[1] = 0.8,
		[2] = 0,
		[3] = 0.8,
		[4] = 0.8,
	},
	[15] = {
		[1] = 0,
		[2] = 0.4,
		[3] = 1,
		[4] = 0.8,
	},
	[16] = {
		[1] = 0.5,
		[2] = 0,
		[3] = 0,
		[4] = 0.8,
	},
	[17] = {
		[1] = 0,
		[2] = 0.5,
		[3] = 0,
		[4] = 0.8,
	},
	[18] = {
		[1] = 0.5,
		[2] = 0.5,
		[3] = 0.5,
		[4] = 0.8,
	},
	[19] = {
		[1] = 0.5,
		[2] = 0.3,
		[3] = 0.7,
		[4] = 0.8,
	},
	[20] = {
		[1] = 0.5,
		[2] = 0.5,
		[3] = 0.7,
		[4] = 0.8,
	},
}
DamageMeters_contributorList = {
}
DamageMeters_eventDataLevel = 2
DamageMeters_textState = 0
DamageMeters_debug4 = {
	["syncSelfTestMode"] = false,
	["showParse"] = false,
	["showSyncQueueInfo"] = false,
	["showValueChanges"] = false,
	["showSyncChanges"] = false,
	["syncSelf"] = false,
	["showAll"] = false,
	["showGCInfo"] = false,
	["showHealthChanges"] = false,
	["msgWatchMode"] = false,
}
DMT_ACTIVE = 1
DMT_SAVED = 2
DMT_VISIBLE = 1
DamageMeters_quantitiesFilter = {
	[1] = true,
	[2] = true,
	[3] = true,
	[4] = true,
	[8] = true,
	[9] = false,
	[10] = false,
	[11] = false,
	[15] = true,
}
DamageMeters_tableInfo = {
	[1] = {
		["sessionIndex"] = 1,
		["sessionLabel"] = "Default",
	},
	[2] = {
		["sessionIndex"] = 1,
		["sessionLabel"] = "Default",
	},
	[3] = {
		["sessionIndex"] = 1,
		["sessionLabel"] = "Default",
	},
}
DMTIMERMODE = 0
DamageMeters_viewMode = 1
DamageMeters_debugEnabled = false
DamageMeters_flags = {
	[1] = true,
	[2] = false,
	[3] = true,
	[4] = false,
	[5] = false,
	[6] = true,
	[7] = false,
	[10] = true,
	[11] = false,
	[13] = false,
	[14] = true,
	[15] = true,
	[16] = false,
	[17] = false,
	[18] = true,
	[19] = true,
	[20] = false,
	[21] = false,
	[22] = false,
	[23] = false,
	[24] = false,
	[25] = true,
	[26] = false,
}
DamageMeters_savedBarCount = 1
DamageMeters_BARWIDTH = 119
DamageMeters_pluginDMITable = {
}
DM_eventCaseTableDebug = nil
