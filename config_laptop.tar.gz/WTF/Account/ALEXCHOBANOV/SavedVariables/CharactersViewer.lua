
CharactersViewerProfile = {
	["RetroWoW"] = {
		["Bankes"] = {
			["Equipment"] = {
				[16] = {
					["T"] = "Interface\\Icons\\INV_Hammer_15",
					["L"] = "item:2361:0:0:0",
				},
				[7] = {
					["T"] = "Interface\\Icons\\INV_Pants_02",
					["L"] = "item:6118:0:0:0",
				},
				[4] = {
					["T"] = "Interface\\Icons\\INV_Shirt_01",
					["L"] = "item:6117:0:0:0",
				},
				[8] = {
					["T"] = "Interface\\Icons\\INV_Boots_01",
					["L"] = "item:43:0:0:0",
				},
			},
			["Type"] = "Self",
			["Bag"] = {
				[1] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Scroll_03",
						["L"] = "item:12720:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\Spell_Nature_Earthquake",
						["L"] = "item:17011:0:0:0",
					},
					[3] = {
						["C"] = 16,
						["L"] = "item:20863:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Clay",
					},
					[4] = {
						["C"] = 2,
						["L"] = "item:18562:0:0:0",
						["T"] = "Interface\\Icons\\INV_Stone_SharpeningStone_01",
					},
					[5] = {
						["C"] = 3,
						["L"] = "item:20867:0:0:0",
						["T"] = "Interface\\Icons\\INV_QirajIdol_Onyx",
					},
					[6] = {
						["C"] = 2,
						["L"] = "item:20873:0:0:0",
						["T"] = "Interface\\Icons\\INV_QirajIdol_Alabaster",
					},
					[7] = {
						["C"] = 18,
						["L"] = "item:20865:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Ivory",
					},
					[8] = {
						["T"] = "Interface\\Icons\\INV_QirajIdol_Vermillion",
						["L"] = "item:20872:0:0:0",
					},
					[9] = {
						["C"] = 2,
						["L"] = "item:20869:0:0:0",
						["T"] = "Interface\\Icons\\INV_QirajIdol_Amber",
					},
					[10] = {
						["T"] = "Interface\\Icons\\INV_QirajIdol_Obsidian",
						["L"] = "item:20871:0:0:0",
					},
					[11] = {
						["C"] = 13,
						["L"] = "item:20861:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Bronze",
					},
					[12] = {
						["C"] = 14,
						["L"] = "item:20862:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Crystal",
					},
					[13] = {
						["C"] = 14,
						["L"] = "item:20858:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Stone",
					},
					[14] = {
						["T"] = "Interface\\Icons\\INV_QirajIdol_Lambent",
						["L"] = "item:20868:0:0:0",
					},
					[15] = {
						["C"] = 14,
						["L"] = "item:20864:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Bone",
					},
					[16] = {
						["C"] = 14,
						["L"] = "item:20860:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Silver",
					},
					["name"] = "Bottomless Bag",
					[17] = {
						["C"] = 24,
						["L"] = "item:20859:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scarab_Gold",
					},
					[18] = {
						["C"] = 3,
						["L"] = "item:19706:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_11",
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[2] = {
					[1] = {
						["T"] = "Interface\\Icons\\INV_Misc_Idol_02",
						["L"] = "item:19819:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Idol_02",
						["L"] = "item:19816:0:0:0",
					},
					[3] = {
						["C"] = 3,
						["L"] = "item:19702:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_13",
					},
					[4] = {
						["T"] = "Interface\\Icons\\INV_Bijou_Bronze",
						["L"] = "item:19713:0:0:0",
					},
					[5] = {
						["T"] = "Interface\\Icons\\INV_Bijou_Blue",
						["L"] = "item:19708:0:0:0",
					},
					[6] = {
						["C"] = 2,
						["L"] = "item:19701:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_07",
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Misc_Idol_02",
						["L"] = "item:19820:0:0:0",
					},
					[8] = {
						["C"] = 2,
						["L"] = "item:19699:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_10",
					},
					[9] = {
						["C"] = 5,
						["L"] = "item:19700:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_09",
					},
					[10] = {
						["C"] = 2,
						["L"] = "item:19704:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_15",
					},
					[11] = {
						["C"] = 4,
						["L"] = "item:19698:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_ArmorKit_11",
					},
					[12] = {
						["T"] = "Interface\\Icons\\INV_Bijou_Green",
						["L"] = "item:19711:0:0:0",
					},
					[13] = {
						["T"] = "Interface\\Icons\\INV_Misc_Book_06",
						["L"] = "item:21283:0:0:0",
					},
					[14] = {
						["T"] = "Interface\\Icons\\INV_Misc_StoneTablet_11",
						["L"] = "item:21292:0:0:0",
					},
					[15] = {
						["T"] = "Interface\\Icons\\INV_Misc_Book_10",
						["L"] = "item:21303:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Misc_Book_08",
						["L"] = "item:21289:0:0:0",
					},
					["name"] = "Bottomless Bag",
					[17] = {
					},
					[18] = {
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[3] = {
					[1] = {
						["C"] = 2,
						["L"] = "item:19705:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Coin_12",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Coin_14",
						["L"] = "item:19703:0:0:0",
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
					},
					[16] = {
					},
					["name"] = "Bottomless Bag",
					[17] = {
					},
					[18] = {
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[4] = {
					[1] = {
						["T"] = "Interface\\Icons\\Ability_Mount_WhiteTiger",
						["L"] = "item:18767:0:0:0",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Rune_01",
						["L"] = "item:6948:0:0:0",
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
						["T"] = "Interface\\Icons\\INV_Misc_Ticket_Tarot_Elemental_01",
						["L"] = "item:19271:0:0:0",
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
						["T"] = "Interface\\Icons\\INV_Misc_Ticket_Tarot_Elemental_01",
						["L"] = "item:19274:0:0:0",
					},
					[12] = {
					},
					[13] = {
					},
					[14] = {
					},
					[15] = {
						["T"] = "Interface\\Icons\\INV_Misc_Ticket_Tarot_Elemental_01",
						["L"] = "item:19272:0:0:0",
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Misc_Ticket_Tarot_Portal_01",
						["L"] = "item:19282:0:0:0",
					},
					["name"] = "Bottomless Bag",
					[17] = {
						["C"] = 2,
						["L"] = "item:300507:0:0:0",
						["T"] = "Interface\\Icons\\INV_Scroll_03",
					},
					[18] = {
					},
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["L"] = "item:14156:0:0:0",
					["size"] = 18,
				},
				[0] = {
					[1] = {
						["C"] = 3,
						["L"] = "item:8146:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_MonsterClaw_01",
					},
					[2] = {
						["T"] = "Interface\\Icons\\INV_Misc_Note_01",
						["L"] = "item:16251:0:0:0",
					},
					[3] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Pearl_03",
						["L"] = "item:12811:0:0:0",
					},
					[4] = {
						["C"] = 2,
						["L"] = "item:22374:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_WartornScrap_Chain",
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
						["T"] = "Interface\\Icons\\INV_Scroll_02",
						["L"] = "item:23055:0:0:0",
					},
					[10] = {
						["C"] = 6,
						["L"] = "item:7078:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Fire_Volcano",
					},
					[11] = {
						["C"] = 2,
						["L"] = "item:5500:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Pearl_02",
					},
					[12] = {
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Bloodstone_03",
						["L"] = "item:11382:0:0:0",
					},
					[13] = {
						["T"] = "Interface\\Icons\\Spell_Nature_StrengthOfEarthTotem02",
						["L"] = "item:7076:0:0:0",
					},
					[14] = {
						["C"] = 2,
						["L"] = "item:17010:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Fire_FlameBolt",
					},
					[15] = {
					},
					[16] = {
						["T"] = "Interface\\Icons\\INV_Ore_Thorium_02",
						["L"] = "item:10620:0:0:0",
					},
					["name"] = "Backpack",
					["Color"] = "ffffffff",
					["T"] = "Interface\\Buttons\\Button-Backpack-Up",
					["size"] = 16,
				},
				[-2] = {
					[1] = {
					},
					[2] = {
					},
					[3] = {
					},
					[4] = {
					},
					[5] = {
					},
					[6] = {
					},
					[7] = {
					},
					[8] = {
					},
					[9] = {
					},
					[10] = {
					},
					[11] = {
					},
					[12] = {
					},
					["name"] = "Keyring",
					["Color"] = "ffffffff",
					["T"] = "Interface\\ContainerFrame\\KeyRing-Bag-Icon",
					["size"] = 12,
				},
			},
			["Timestamp"] = 1516213071,
			["Data"] = {
				["Type"] = "Self",
				["Guild"] = {
					["Rank"] = 0,
				},
				["Honor"] = {
					["HK"] = 0,
					["DK"] = 0,
				},
				["Money"] = 3123246,
				["CombatStats"] = {
					["P"] = 0,
					["C"] = "0.00",
					["D"] = 0,
				},
				["Basic"] = {
					["Defense"] = 1,
					["Health"] = 2231,
					["Armor"] = "124:124:0",
					["Mana"] = 2267,
				},
				["xp"] = {
					["current"] = 0,
					["max"] = 0,
					["timestamp"] = 1516213071,
					["resting"] = false,
				},
				["Location"] = {
					["SubZone"] = "",
					["Zone"] = "Hyjal",
				},
				["Resists"] = {
					[2] = 0,
					[3] = 0,
					[4] = 10,
					[5] = 0,
					[6] = 0,
				},
				["Mail"] = {
					["HasNewMail"] = false,
				},
				["Timestamp"] = 1516213071,
				["Id"] = {
					["ClassEn"] = "PALADIN",
					["SexId"] = 0,
					["Race"] = "Dwarf",
					["Name"] = "Bankes",
					["Sex"] = "Male",
					["Class"] = "Paladin",
					["RaceEn"] = "Dwarf",
					["Level"] = 60,
					["Server"] = "RetroWoW",
				},
				["Stats"] = {
					[1] = "107:107:0:0",
					[2] = "61:61:0:0",
					[3] = "103:103:0:0",
					[4] = "69:69:0:0",
					[5] = "74:74:0:0",
				},
			},
			["Bank"] = {
				[5] = {
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				[6] = {
					[1] = {
						["C"] = 3,
						["L"] = "item:7910:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Ruby_02",
					},
					[2] = {
						["C"] = 4,
						["L"] = "item:12799:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Opal_01",
					},
					[3] = {
						["C"] = 2,
						["L"] = "item:7909:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Crystal_02",
					},
					[4] = {
						["C"] = 8,
						["L"] = "item:12808:0:0:0",
						["T"] = "Interface\\Icons\\Spell_Shadow_ShadeTrueSight",
					},
					[6] = {
						["C"] = 2,
						["L"] = "item:12361:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_Gem_Sapphire_02",
					},
					[7] = {
						["C"] = 2,
						["L"] = "item:18562:0:0:0",
						["T"] = "Interface\\Icons\\INV_Stone_SharpeningStone_01",
					},
					[8] = {
						["L"] = "item:19698:0:0:0",
						["T"] = "Interface\\Icons\\INV_Misc_ArmorKit_11",
					},
					[9] = {
						["C"] = 2,
						["L"] = "item:4338:0:0:0",
						["T"] = "Interface\\Icons\\INV_Fabric_Mageweave_01",
					},
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				[7] = {
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				[8] = {
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				[10] = {
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				["Main"] = {
				},
				[9] = {
					["name"] = "Bottomless Bag",
					["L"] = "item:14156:0:0:0",
					["T"] = "Interface\\Icons\\INV_Misc_Bag_13",
					["size"] = 18,
				},
				["timestamp"] = 1515336435,
			},
		},
	},
}
CharactersViewerConfig = {
	["Bag_Location"] = 0,
	["version"] = 62,
	["Bag_Display"] = true,
	["BankBag_Display"] = true,
}
