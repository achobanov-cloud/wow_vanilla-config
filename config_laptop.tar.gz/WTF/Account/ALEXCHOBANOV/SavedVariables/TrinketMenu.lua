
TrinketMenuOptions = {
	["Notify"] = "OFF",
	["KeepOpen"] = "OFF",
	["ShowIcon"] = "ON",
	["NotifyChatAlso"] = "OFF",
	["Locked"] = "OFF",
	["MenuOnShift"] = "OFF",
	["CooldownCount"] = "OFF",
	["TooltipFollow"] = "OFF",
	["IconPos"] = -100,
	["NotifyUsedOnly"] = "OFF",
	["NotifyThirty"] = "OFF",
	["DisableToggle"] = "OFF",
	["ShowTooltips"] = "ON",
	["SquareMinimap"] = "OFF",
	["KeepDocked"] = "ON",
}
