
Mail_AutoCompleteNames = {
	["RetroWoW|Alliance"] = {
		["Bankes"] = 1733.5,
	},
}
