
CooldownCount_Enabled = 0
CooldownCount_NoSpaces = 0
CooldownCount_SideBarsSideCount = nil
CooldownCount_UseLongTimerDescriptions = 0
CooldownCount_UseLongTimerDescriptionsForSeconds = 0
CooldownCount_TimeBetweenFlashes = 0.5
CooldownCountOptions = {
	["color"] = {
		["normal"] = {
			[1] = 1,
			[2] = 0.82,
			[3] = 0,
		},
		["flash"] = {
			[1] = 1,
			[2] = 0.12,
			[3] = 0.12,
		},
	},
	["alpha"] = 1,
}
CooldownCount_UserScale = 2
CooldownCount_RogueStealth = 0
